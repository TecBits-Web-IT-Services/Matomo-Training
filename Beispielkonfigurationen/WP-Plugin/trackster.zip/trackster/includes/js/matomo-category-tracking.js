if (typeof tracksterCategoryData !== 'undefined') {
    _paq = _paq || [];
    _paq.push(['setEcommerceView',
        false,
        false,
        tracksterCategoryData.categoryName
    ]);
}