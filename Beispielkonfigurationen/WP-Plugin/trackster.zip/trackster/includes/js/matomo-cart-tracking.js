if (typeof tracksterCartData !== 'undefined' && tracksterCartData.items.length > 0) {
    _paq = _paq || [];
    tracksterCartData.items.forEach(function (item) {
        _paq.push(['addEcommerceItem',
            item.sku,
            item.name,
            item.category,
            item.price,
            item.quantity
        ]);
    });
    _paq.push(['trackEcommerceCartUpdate', tracksterCartData.cartTotal]);
}
