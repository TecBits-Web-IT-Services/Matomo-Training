if (typeof tracksterOrderData !== 'undefined') {
    _paq = _paq || [];

    tracksterOrderData.items.forEach(function (item) {
        _paq.push(['addEcommerceItem',
            item.sku,
            item.name,
            item.category_name,
            item.price,
            item.quantity
        ]);
    });

    _paq.push(['trackEcommerceOrder',
        tracksterOrderData.order_number,
        tracksterOrderData.total,
        tracksterOrderData.subtotal,
        tracksterOrderData.total_tax,
        tracksterOrderData.shipping_total,
        false
    ]);
}