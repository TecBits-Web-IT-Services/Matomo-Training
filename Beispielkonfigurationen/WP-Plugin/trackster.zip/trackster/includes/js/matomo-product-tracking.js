if (typeof tracksterProductData !== 'undefined') {
    _paq = _paq || [];
    _paq.push(['setEcommerceView',
        tracksterProductData.sku,
        tracksterProductData.name,
        tracksterProductData.categoryList,
        tracksterProductData.price
    ]);
};