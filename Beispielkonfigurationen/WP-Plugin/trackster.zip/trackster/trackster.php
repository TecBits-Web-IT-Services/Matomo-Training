<?php
defined('ABSPATH') || die();

/**
 * Plugin Name: Trackster (TecBits)
 * Description: Trackster is a free plugin to integrate Matomo eCommerce tracking with WooCommerce.
 * Version: 1.0.2
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Author: Florian in der Beek
 * Author URI: https://www.tecbits.de/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: Trackster
 * Domain Path: /languages
 */

/**
 * Load translations
 */
function trackster_load_textdomain()
{
    load_plugin_textdomain('trackster', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('init', 'trackster_load_textdomain');

/**
 * Check if WooCommerce is installed and activated
 */
function trackster_is_woocommerce_installed()
{
    include_once(ABSPATH . 'wp-admin/includes/plugin.php');
    return is_plugin_active('woocommerce/woocommerce.php');
}

if (trackster_is_woocommerce_installed()) {
    require_once plugin_dir_path(__FILE__) . 'includes/class-matomo.php'; // Include Matomo class
} else {
    /**
     * Display an admin notice if WooCommerce is not installed or activated
     */
    function trackster_woocommerce_not_detected()
    {
        echo '<div class="notice notice-error">';
        echo '<p>';
        echo 'Trackster ';
        esc_html_e('requires', 'trackster');
        echo ' <a href="https://woocommerce.com/" target="_blank">WooCommerce</a> ';
        esc_html_e('to be installed and active.', 'trackster');
        echo '</p>';
        echo '</div>';
    }
    add_action('admin_notices', 'trackster_woocommerce_not_detected');
}
